# smartthings-kumo
SmartThings Schema connector for Mitsubishi Kumo Cloud
