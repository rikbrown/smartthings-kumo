const OAuth2Server = require('oauth2-server');

const oauth = new OAuth2Server({
    model: require('./model')
});

exports.handler = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));

    let request = new OAuth2Server.Request({
        method: event['requestContext']['http']['method'],
        query: event['queryStringParameters'],
        headers: event['headers']
    });
    let response = new OAuth2Server.Response();

    console.log(request);

    let body;
    let statusCode = '200';
    const headers = {
        'Content-Type': 'text/plain',
    };

    body = 'hello';

    return oauth.authenticate(request, response)
        .then(function(code) {
            let r = {
                statusCode,
                body,
                headers,
            };
            resolve(r)
        });
};
